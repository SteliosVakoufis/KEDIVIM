package gr.aueb.elearn.miniprojects.project_08;

public class app {
    
    public static void main(String[] args) {
        TicTacToe game = new TicTacToe();
        game.sitOnTable();
    }
}
