package gr.aueb.elearn.miniprojects.project_02;

public class app {
    public static void main(String[] args) {
        MobilePhone myMobilePhone = new MobilePhone(500);
        myMobilePhone.menu();
    }
}
