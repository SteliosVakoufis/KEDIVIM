package gr.aueb.elearn.chapter14.exercises.ex2;

public interface ITwoDimensional {
    public double getArea();

    public long getCircumference();
}
