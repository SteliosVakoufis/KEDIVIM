package gr.aueb.elearn.chapter14.exercises.ex2;

public interface ILine extends IShape {
}
