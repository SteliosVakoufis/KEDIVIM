package gr.aueb.elearn.chapter14.exercises.ex1;

public interface ITwoDimensional {
    public double getArea();
}
