package gr.aueb.elearn.chapter14.exercises.ex2;

public interface ICircle extends IShape, ITwoDimensional {
    public double getDiamter();
}
