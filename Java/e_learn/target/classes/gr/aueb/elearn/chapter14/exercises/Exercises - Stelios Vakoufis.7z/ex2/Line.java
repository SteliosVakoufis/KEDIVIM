package gr.aueb.elearn.chapter14.exercises.ex2;

public class Line extends AbstractShape implements ILine {
    private double length;
}
