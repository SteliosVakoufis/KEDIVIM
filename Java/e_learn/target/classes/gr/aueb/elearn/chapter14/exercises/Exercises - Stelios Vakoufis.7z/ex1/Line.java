package gr.aueb.elearn.chapter14.exercises.ex1;

public class Line extends AbstractShape {
    private double length;
}
