package gr.aueb.elearn.chapter14.exercises.ex2;

public interface IRectangle extends IShape, ITwoDimensional {
}
