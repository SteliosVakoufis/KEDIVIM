package gr.aueb.elearn.chapter14.exercises.ex1;

public interface IShape {
    public long getId();
}
